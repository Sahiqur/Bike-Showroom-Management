import os
import datetime


bike_list=[
    {
        "name":"R-15",
        "brand":"Yamaha",
        "model":"1001",
        "quantity":10,
    },
    {
        "name":"Gixxer",
        "brand":"Suzuki",
        "model":"1002",
        "quantity":20,
    },
    
]

lend_bike=[
    
]


def add_bike():
    bike_information=input("Enter Your Bike name or Model Number : ")
    
    for bike in bike_list:
        if bike_information.lower() in bike["name"].lower() or bike_information.lower() in bike["model"].lower():
            print("Warning : Bike already exitst")
            return
    else:
        name=input("Enter Your Bike Name : ")
        brand=input("Enter Your Brand Name : ")
        model=input("Enter Your Bike Model Number : ")
        quantity=int(input("Enter Your Bike Quantity : "))
        
        new_bike={
            "name":name,
            "brand":brand,
            "model":model,
            "quantity":quantity,
        }
        bike_list.append(new_bike)
        
        with open("bike.csv","w") as f:
            for bike in bike_list:
                f.write(
                    f'{bike["name"]} | {bike["brand"]} | {bike["model"]} | {bike["quantity"]} \n'
                )
        
        print("Bike Added Succesfully")
            
    
def show_bike():
    
    for bike in bike_list:
        print(
            f'{bike["name"]} | {bike["brand"]} | {bike["model"]} | {bike["quantity"]}')
    

def remove_bike():
    # search_item=input("Enter Your item for remove : ")
    # for index,bike in enumerate(bike_list):
    #     if search_item in bike["model"] or search_item.lower() in bike["brand"].lower() or search_item.lower() in bike["name"].lower():
    #         print(
    #         f'{index+1}. Found : {bike["name"]} | {bike["brand"]} | {bike["model"]} | {bike["quantity"]}'
    #         )
    # else:
    #     print("Not Founded")
    #     return 
    
    # by using function I can handle a term
    
    search_bike()
    
    agree=input("Do you want to delete this item ? (Yes/No) : ")
    if agree.lower() == "Yes".lower():
        index_item = int(input("Enter the index number for remove : "))
        bike_list.pop(index_item-1)
        print("Deleted Succesfully")
    elif agree.lower() == "No".lower():
        print("You do not want to remove item.")
    else:
        print("Please enter yes or no ")
        
    
            
def search_bike():
    search_item=input("Enter Your item for remove : ")
    for index,bike in enumerate(bike_list):
        if search_item in bike["model"] or search_item.lower() in bike["brand"].lower() or search_item.lower() in bike["name"].lower():
            print(
            f'{index+1}. Found : {bike["name"]} | {bike["brand"]} | {bike["model"]} | {bike["quantity"]}'
            )
    else:
        print("Not Founded")
        
        
#borrow function
def save_borrow_bike(bike):
    
    if not os.path.exists("bike_lent.csv"):
        open("lbike_lent.csv","w").close()
    
    
    with open("bike_lent.csv","a") as f:
        f.write(
            f'{bike["name"]} | {bike["model"]} | {bike["customer_name"]} | {bike["selling_date"]} | {bike["price"]}\n'
        )

def load_bike_borrow():
    if not os.path.exists("bike_lent.csv"):
        open("bike_lent.csv","w").close()
    
    if os.path.getsize("bike_lent.csv")==0:
        return
    
    with open("bike_lent.csv","r") as f:
        for line in f:
            name,model,customer_name,selling_date,price
            
            lend_bike.append(
                {
                    "name":name,
                    "model":model,
                    "customer_name":customer_name,
                    "selling_date":selling_date,
                    "price":price,
                }
            )
            

def update_bike_lent():
    with open("bike_lent.csv","w") as f:
        for bike in lend_bike:
            f.write(
                f'{bike["name"]} | {bike["model"]} | {bike["customer_name"]} | {bike["selling_date"]} | {bike["price"]}\n'
            )
            
def bike_borrow():
    key = input("Enter Your Search Item : ")
    for bike in bike_list:
        if key.lower() in bike["model"].lower() or key.lower() in bike["name"].lower():
            if bike["quantity"]>0:
                print(f"Bike is Available for sell")
                customer_name=input("Enter Customer Name : ")
                selling_date=input("Selling Date (YYYY-MM-DD): ")
                price=input("Enter the Selling Price : ")
                borrow_bike={
                    "name":bike["name"],
                    "model":bike["model"],
                    "brand":bike["brand"],
                    "customer_name":customer_name,
                    "selling_date":selling_date,
                    "price":price,
                }
                lend_bike.append(borrow_bike)
                bike["quantity"]=bike["quantity"]-1
                
                save_borrow_bike(borrow_bike)
                break
            else:
                print(f'Sorry, {book["title"]} is out of stock')
                break
        else:
            print("Book Not Found")
    print("\nUpdate Information")
    print("====================")
    show_bike()          
        
def display_borrow_bike():
    for information in lend_bike:
        print(
            f'{information["customer_name"]} | {information["name"]} | {information["model"]} | {information["selling_date"]} | {information["price"]}'
        )
                
            

    
        
            
            
        
    
     










while True:
    print("\n Bike Showroom Management System")
    print("==================================")
    print("1. Add New Bike")
    print("2. Show Bike Information")
    print("3. Remove Bike Information")
    print("4. Search Bike Information")
    print("5. Bike Borrow")
    print("6. Display Borrow Bike")
    print("7. Exit")
    
    choice=input("Enter Your Choice (1-8) : ")

    if choice == "1":
        add_bike()
    elif choice == "2":
        show_bike()
    elif choice == "3":
        remove_bike()
    elif choice == "4":
        search_bike()
    elif choice == "5":
        bike_borrow()
    elif choice == "6":
        display_borrow_bike()
    elif choice == "7" or choice.lower() == "exit":
        print("Exit")
        break
    else:
        print("Sorry! Wrong Choice")
        
print("Thank You For Using this Software")
        
        
        











